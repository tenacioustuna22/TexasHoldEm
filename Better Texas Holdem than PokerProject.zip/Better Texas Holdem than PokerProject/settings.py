
FPS = 60
width = 1920
height = 1080
font = 'graphics/fonts/GOTHIC.TTF'
audio_dir = 'audio/'
