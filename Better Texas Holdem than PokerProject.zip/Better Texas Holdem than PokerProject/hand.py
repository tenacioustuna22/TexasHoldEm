import pygame, random, itertools, os, re, sys, cards, re
from cards import Deck, Hand, Player, Dealer

class Hand:
    def __init__(self, rank, suit):
        self.cards = []
        self.value_dict = rank
        self.suit_dict = suit
        return f"{self.rank} of {self.suit}"

class Deck: 
    def __init__(self):
        self.cards = [Hand(value, suit) for suit in Hand.suits for value in Hand.values]
        random.shuffle(self.cards)
    
    def deal(self):
        return self.cards.pop() if self.cards else None

class Player:
    def __init__(self, name, chips):
        self.name = name
        self.chips = chips
        self.hand = []

    def bet(self, amount):
        if amount > self.chips:
            raise "Not enough chips"
        self.chips -= amount
        return f"{self.name} bet {amount} chips"

    def __str__(self):
        return f"{self.name} has {self.chips} chips"
    
#Evaluate the hand

class Dealer: 
    def __init__(self):
        self.deck = Deck()
        self.community_cards = []
        self.players = []
        self.pot = 0
        self.burn_pile = []
        self.phase = 0
        self.stats = {'player': None, 'hand': None, 'value': None, 'kicker': None}

    def deal(self):