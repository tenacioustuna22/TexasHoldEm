from hand import Hand, Deck, Player, Dealer

player1_bet = input(f"{Player.name}: {} ")