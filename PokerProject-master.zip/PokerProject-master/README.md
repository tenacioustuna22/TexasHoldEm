# PokerProject
## A practice project by Ben McGauhey
The Poker Project is a chance for me to brush up on programming and statistics at the same time.
Started during the summer of 2017 and largely left untouched after a couple of weeks of messing with it, it remains unfinished.
The functions.py contains enough functions to deal a hand of texas hold em in the the console, then find whether the user has
been dealt a flush, straight, etc. The classes.py creates classes to be utilized by PyGame for a GUI.
game_functions.py and pygame_main.py work together with the above to deal a hand out to the player, and then deal the flop,
turn, and river to the table. This works, except that when dealing a second or more hand, the first instance simply repeats.
This is the present state of the project, waiting on me to fix that bug and move it ahead.
